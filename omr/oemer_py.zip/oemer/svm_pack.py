# SVC (RBF) modellerini kompakt ikili dosyaya çevirir ve numpy ile tahmin eder (libsvm one-vs-one oylaması)
import pickle, json, struct, sys
import numpy as np

AD = ['clef', 'rests', 'rests_above8', 'sfn']

def paketle(kaynak_dizin, hedef):
    bilgi = {}
    parcalar = []
    konum = 0
    for ad in AD:
        d = pickle.load(open('%s/%s.model' % (kaynak_dizin, ad), 'rb'))
        m = d['model']
        sv = np.round(m.support_vectors_).astype(np.uint8)
        assert np.allclose(sv, m.support_vectors_)
        dc = np.asarray(getattr(m, '_dual_coef_', m.dual_coef_), dtype=np.float32)
        ic = np.asarray(getattr(m, '_intercept_', m.intercept_), dtype=np.float32)
        cm = d['class_map']
        etiket = [cm[i] for i in range(len(m.classes_))]
        ogeler = {'sv': sv, 'dc': dc, 'ic': ic}
        kayit = {'w': int(d['w']), 'h': int(d['h']), 'gamma': float(m._gamma), 'nsup': [int(x) for x in m.n_support_],
                 'etiket': etiket, 'siniflar': [int(x) for x in m.classes_], 'diziler': {}}
        for k, a in ogeler.items():
            b = a.tobytes()
            kayit['diziler'][k] = {'dtype': str(a.dtype), 'shape': list(a.shape), 'offset': konum, 'nbyte': len(b)}
            parcalar.append(b)
            konum += len(b)
        bilgi[ad] = kayit
    bas = json.dumps(bilgi).encode()
    with open(hedef, 'wb') as f:
        f.write(b'SVMPK1')
        f.write(struct.pack('<I', len(bas)))
        f.write(bas)
        for b in parcalar:
            f.write(b)

def yukle(veri):
    assert veri[:6] == b'SVMPK1'
    n = struct.unpack('<I', veri[6:10])[0]
    bilgi = json.loads(veri[10:10 + n].decode())
    govde = memoryview(veri)[10 + n:]
    modeller = {}
    for ad, k in bilgi.items():
        dz = {}
        for ke, v in k['diziler'].items():
            a = np.frombuffer(govde[v['offset']:v['offset'] + v['nbyte']], dtype=v['dtype']).reshape(v['shape'])
            dz[ke] = a
        k = dict(k)
        k['sv'] = dz['sv'].astype(np.float32)
        k['dc'] = dz['dc'].astype(np.float64)
        k['ic'] = dz['ic'].astype(np.float64)
        k['sv_sq'] = (k['sv'].astype(np.float64) ** 2).sum(1)
        modeller[ad] = k
    return modeller

def tahmin(m, x):
    # x: (n_ozellik,) uint8/float. libsvm one-vs-one oylaması; eşitlikte küçük sınıf indisi
    x = np.asarray(x, dtype=np.float64).reshape(-1)
    d2 = m['sv_sq'] - 2.0 * (m['sv'].astype(np.float64) @ x) + float(x @ x)
    K = np.exp(-m['gamma'] * np.maximum(d2, 0.0))
    n = len(m['nsup'])
    baslar = np.concatenate([[0], np.cumsum(m['nsup'])])
    oy = np.zeros(n)
    p = 0
    for i in range(n):
        for j in range(i + 1, n):
            si, sj = baslar[i], baslar[j]
            ci = m['dc'][j - 1, si:si + m['nsup'][i]]
            cj = m['dc'][i, sj:sj + m['nsup'][j]]
            dec = ci @ K[si:si + m['nsup'][i]] + cj @ K[sj:sj + m['nsup'][j]] + m['ic'][p]
            if dec > 0:
                oy[i] += 1
            else:
                oy[j] += 1
            p += 1
    return m['etiket'][int(np.argmax(oy))]

if __name__ == '__main__':
    paketle(sys.argv[1], sys.argv[2])
