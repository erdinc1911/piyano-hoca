# Tarayıcı sürümü: yalnızca SVC tahmini (model çıkarımı JavaScript tarafında yapılır)
import numpy as np
from PIL import Image
from oemer import svm_pack

_MODELLER = None

def modelleri_yukle(veri):
    global _MODELLER
    _MODELLER = svm_pack.yukle(veri)

def predict(region, model_name):
    if np.max(region) == 1:
        region *= 255
    m = _MODELLER[model_name]
    region = np.array(Image.fromarray(region.astype(np.uint8)).resize((m['w'], m['h'])))
    return svm_pack.tahmin(m, region.reshape(-1))
