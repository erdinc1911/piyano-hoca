"""Tarayıcıda (Pyodide) ve masaüstünde çalışan oemer hattı.
Girdi: iki sınıf haritası (JavaScript'te ONNX ile üretilir) ve görüntü. Çıktı: MusicXML baytları."""
import numpy as np
import cv2


def temizle():
    from oemer import layers
    for l in layers.list_layers():
        layers.delete_layer(l)


def calistir(harita1, harita2, goruntu_bgr, deskew=True, baslik='Nota', ilerleme=None):
    """harita1: (H,W) uint8 0=zemin 1=porte 2=semboller (birinci model)
    harita2: (H,W) uint8 0=zemin 1=sap/es 2=nota başı 3=anahtar/arti-eksi (ikinci model)
    goruntu_bgr: (H,W,3) uint8"""
    from oemer import layers
    from oemer.dewarp import estimate_coords, dewarp
    from oemer.staffline_extraction import extract as staff_extract
    from oemer.notehead_extraction import extract as note_extract
    from oemer.note_group_extraction import extract as group_extract
    from oemer.symbol_extraction import extract as symbol_extract
    from oemer.rhythm_extraction import extract as rhythm_extract
    from oemer.build_system import MusicXMLBuilder

    def adim(ad):
        if ilerleme:
            ilerleme(ad)

    temizle()
    staff = np.where(harita1 == 1, 1, 0)
    symbols = np.where(harita1 == 2, 1, 0)
    stems_rests = np.where(harita2 == 1, 1, 0)
    notehead = np.where(harita2 == 2, 1, 0)
    clefs_keys = np.where(harita2 == 3, 1, 0)
    image = cv2.resize(goruntu_bgr, (staff.shape[1], staff.shape[0]))

    if deskew:
        adim('Sayfa düzeltiliyor')
        coords_x, coords_y = estimate_coords(staff)
        staff = dewarp(staff, coords_x, coords_y)
        symbols = dewarp(symbols, coords_x, coords_y)
        stems_rests = dewarp(stems_rests, coords_x, coords_y)
        clefs_keys = dewarp(clefs_keys, coords_x, coords_y)
        notehead = dewarp(notehead, coords_x, coords_y)
        for i in range(image.shape[2]):
            image[..., i] = dewarp(image[..., i], coords_x, coords_y)

    symbols = symbols + clefs_keys + stems_rests
    symbols[symbols > 1] = 1
    layers.register_layer('stems_rests_pred', stems_rests)
    layers.register_layer('clefs_keys_pred', clefs_keys)
    layers.register_layer('notehead_pred', notehead)
    layers.register_layer('symbols_pred', symbols)
    layers.register_layer('staff_pred', staff)
    layers.register_layer('original_image', image)

    adim('Porte çizgileri bulunuyor')
    staffs, zones = staff_extract()
    layers.register_layer('staffs', staffs)
    layers.register_layer('zones', zones)

    adim('Nota başları bulunuyor')
    notes = note_extract()
    layers.register_layer('notes', np.array(notes))
    layers.register_layer('note_id', np.zeros(symbols.shape, dtype=np.int64) - 1)
    symbols_l = layers.get_layer('symbols_pred')
    note_id = layers.get_layer('note_id')
    for idx, note in enumerate(layers.get_layer('notes')):
        x1, y1, x2, y2 = note.bbox
        yi, xi = np.where(symbols_l[y1:y2, x1:x2] > 0)
        yi += y1
        xi += x1
        note_id[yi, xi] = idx
        layers.get_layer('notes')[idx].id = idx

    adim('Notalar gruplanıyor')
    groups, group_map = group_extract()
    layers.register_layer('note_groups', np.array(groups))
    layers.register_layer('group_map', group_map)

    adim('Semboller tanınıyor')
    barlines, clefs, sfns, rests = symbol_extract()
    layers.register_layer('barlines', np.array(barlines))
    layers.register_layer('clefs', np.array(clefs))
    layers.register_layer('sfns', np.array(sfns))
    layers.register_layer('rests', np.array(rests))

    adim('Ritim çözülüyor')
    rhythm_extract()

    adim('MusicXML hazırlanıyor')
    builder = MusicXMLBuilder(title=baslik)
    builder.build()
    return builder.to_musicxml()
